
var greeting = "Hello, playground"
// 1. Functions
print("1. Functions")
//1
print("Exercise 1:")
func minValue(number1: Int, number2: Int) -> Int{
    if number1 < number2 {
        return number1
    }
    else {
        return number2
    }
}

print(minValue(number1: 3, number2: 3))
print(minValue(number1: 7, number2: 12))
print(minValue(number1: 71, number2: 13))

//2
print("Exercise 2:")
func lastDigit(_ number: Int) -> Int{
    return number % 10
}

print(lastDigit(31))
print(lastDigit(8124))

//3
print("Exercise 3:")
func divides(_ number1: Int,_ number2: Int) -> Bool{
    return number1 % number2 == 0
}

func countDivisors(_ number: Int) -> Int{
    var counter = 0
    for i in 1...number {
        if divides(number, i) {
            counter += 1
        }
    }
    return counter;
}

func isPrime(_ number: Int) -> Bool{
    if countDivisors(number) == 2 {
        return true
    }
    return false
}


divides(7, 3) // false - 7 is not divisible by 3
divides(8, 4) // true - 8 is divisible by 4

countDivisors(1) // 1 - 1
countDivisors(10) // 4 - 1, 2, 5 and 10
countDivisors(12) // 6 - 1, 2, 3, 4, 6 and 12
 
isPrime(3) // true
isPrime(8) // false
isPrime(13) // true

// 2. Clousers
//1
func smartBart(n: Int, closure: () -> ()) {
    for _ in 1...n {
        closure()
    }
}

var printB: () -> () = {
    print("I will pass this course with best mark, because Swift is great!")
}

smartBart(n: 5, closure: printB)
//2
let numbers = [10, 16, 18, 30, 38, 40, 44, 50]
print(numbers.filter{$0 % 4 == 0})
//3

print(numbers.reduce(0){(a,b) -> (Int) in if(a>b){return a} else{return b}}) //TODO spróbować zmienić

//4
var strings = ["Gdansk", "University", "of", "Technology"]
print(strings.reduce(""){if $0 == ""{return $0 + $1} else{return $0 + " " + $1}}) //TODO spróbować zmienić, closure do zmiennej

//5
let numbers1 = [1, 2 ,3 ,4, 5, 6]
print(numbers1.filter{$0 % 2 == 1}.map{$0 * $0}.reduce(0){$0 + $1})

// 3. Touples

//1
func minmax(number1: Int, number2: Int) -> (max: Int, min: Int) {
    if(number1 > number2){
        return (number1,number2)
    }
    else {
        return (number2,number1)
    }
}

var x = minmax(number1: 5, number2: 7)
print(x.max)
print(x.min)
//2

var stringsArray = ["gdansk", "university", "gdansk", "university", "university", "of", "technology", "technology","gdansk", "gdansk"]

var uniqstrings = [String]()

for string1 in stringsArray {
    var p = 1
    for string2 in uniqstrings {
        if string1 == string2 {
            p = 0
        }
    }
    if p == 1 {
        uniqstrings.append(string1)
    }
}
var countedStrings = [(String,Int)]()

for uniqstring in uniqstrings {
    var counter = 0
    for string in stringsArray {
        if uniqstring == string {
            counter += 1
        }
    }
    countedStrings.append((uniqstring,counter))
}
print(countedStrings)

enum Day: Int {
    case Monday = 1
    case Tuesday = 2
    case Wednesday = 3
    case Thursday = 4
    case Friday = 5
    case Saturday = 6
    case Sunday = 7
    
    func emojidesc() -> (String){
        switch self{
        case .Monday:
            return "🌨"
        case .Tuesday:
            return "⚡️"
        case .Wednesday:
            return "🍀"
        case .Thursday:
            return "🩴"
        case .Friday:
            return "🕶"
        case .Saturday:
            return "🎉"
        case .Sunday:
            return "☀️"
        }
    }
}
var d = Day.Friday
print(d.rawValue)
print(d.emojidesc())
