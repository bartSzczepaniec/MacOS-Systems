import Cocoa
import CoreGraphics
import Darwin


// Instagram post data structure and helper functions

func dateDiff(_ date1: Date, _ date2: Date) -> Int {
    let calendar = Calendar.current
    let d1 = calendar.startOfDay(for: date1)
    let d2 = calendar.startOfDay(for: date2)
    let comp = calendar.dateComponents([.day], from: d1, to: d2)
    return comp.day ?? 0
    
}

enum MediaType {
    case Photo
    case Video
}

struct Comment {
    var content:String
    var likes=0
    var edited:Bool
    var date:Date
    var author:User
    init(_ content: String, _ likes: Int, _ edited: Bool, _ date: Date, _ author: User)
    {
        self.content = content
        self.likes = likes
        self.edited = edited
        self.date = date
        self.author = author
    }
}

class Media {
    var source:String
    var type:MediaType
    init(_ source:String, _ type:MediaType)
    {
        self.source = source
        self.type = type
    }
}

class Photo: Media {
    var taggedUsers = Array<User>()
    init(_ source: String, _ taggedUsers: Array<User>) {
        super.init(source, MediaType.Photo)
        self.taggedUsers = taggedUsers
    }
}

class Video: Media {
    var length = 0
    init(_ source: String, _ length: Int) {
        super.init(source, MediaType.Video)
        self.length = length
    }
}

class User {
    var username:String
    var imgsrc:String
    init(_ username: String, _ imgsrc: String)
    {
        self.username = username
        self.imgsrc = imgsrc
    }
}

class Post {
    var author:User
    var decription:String
    var media = Array<Media>()
    var comments = Array<Comment>()
    var usersThatLiked = Array<User>()
    var date:Date
    init(_ author: User, _ description: String, _ media: Array<Media>, _ comments: Array<Comment>, _ date:Date, _ usersThatLiked: Array<User>)
    {
        self.author = author
        self.decription = description
        self.media = media
        self.comments = comments
        self.date = date
        self.usersThatLiked = usersThatLiked
    }
    func show(){
        print("Post | Autor: " + author.username + " | Opis: " + decription + " | Polubienia: " + showWhoLiked(usersThatLiked) + " | Zawartość:")
        for medium in media {
            if medium.type == MediaType.Video {
                let vid:Video = medium as! Video
                print("Wideo: " + vid.source + " | dlugosc: " + String(vid.length) + "s")
            }
            if medium.type == MediaType.Photo {
                let photo:Photo = medium as! Photo
                print("Zdjecie: " + photo.source + " | Oznaczeni uzytkownicy: ",terminator: " ")
                if photo.taggedUsers.count > 0 {
                for tagged in photo.taggedUsers {
                    print(tagged.username, terminator: " ")
                }
                }
                print("")
            }
        }
        showDateDiff(date)
        showComments(comments)
    }
}
func showComments(_ comments:Array<Comment>) {
    print("Komentarze:")
    for comment in comments {
        var output = comment.author.username
        output += ": "
        output += comment.content
        output += " | Polubienia: "
        output += String(comment.likes)
        if comment.edited {
            output += " | (Edytowany)"
        }
        output += " |"
        print(output,terminator: " ")
        showDateDiff(comment.date)
    }
}

func showDateDiff(_ postDate: Date) {
    let days = dateDiff(postDate, Date.now)
    if days == 0 {
        print("Opublikowano: Dzisiaj")
        return
    }
    else if days < 7{
        print("Opublikowano: " + String(days) + " dni temu")
    }
    else if days < 14 {
        print("Opublikowano: Tydzien temu")
    }
    else if days < 31 {
        print("Opublikowano: " + String(days/7) + " tygodnie temu")
    }
    else if days < 62 {
        print("Opublikowano: Miesiac temu")
    }
    else if days < 365 {
        print("Opublikowano: " + String(days/31) + " miesiace temu")
    }
    else if days < 365 * 2 {
        print("Opublikowano: Rok temu")
    }
    else {
        print("Opublikowano: " + String(days/365) + " lata temu")
    }
}

func showWhoLiked(_ usersThatLiked: Array<User>) -> String {
    if usersThatLiked.count == 0 {
        return ""
    }
    else if usersThatLiked.count == 1 {
        return usersThatLiked.first?.username ?? ""
    }
    else {
        var output = usersThatLiked.first?.username ?? ""
        output += " i inni użytkownicy lubią to"
        return output
    }
}

func showPosts(_ posts:Array<Post>)
{
    for post in posts {
        post.show()
        print("")
    }
}

// Dane testowe
let stringDate = "2-02-2022"
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "dd-MM-yyyy"
let date1 = dateFormatter.date(from: stringDate) ?? Date.now
var date2 = dateFormatter.date(from: "4-10-2010") ?? Date.now


var users = Array<User>()
users.append(User("nickname0","img42.jpg"))
users.append(User("nickname1","img42.jpg"))
users.append(User("nickname2","img42.jpg"))
users.append(User("nickname3","img42.jpg"))
users.append(User("nickname4","img42.jpg"))
users.append(User("nickname5","img42.jpg"))
users.append(User("nickname6","img42.jpg"))
users.append(User("nickname7","img42.jpg"))
users.append(User("nickname8","img42.jpg"))
users.append(User("nickname9","img42.jpg"))


var tagged1 = Array<User>()
tagged1.append(users[1])
var p1 = Photo("photo1.jpg", tagged1)

var tagged2 = Array<User>()
tagged2.append(users[3])
tagged2.append(users[2])
var p2 = Photo("photo2.jpg", tagged2)


var medias = Array<Media>()
medias.append(p1)
medias.append(p2)

var comments = Array<Comment>()
date2 = dateFormatter.date(from: "2-02-2022") ?? Date.now
comments.append(Comment("komentarz1", 13, true, date2, users[5]))
date2 = dateFormatter.date(from: "2-03-2022") ?? Date.now
comments.append(Comment("komentarz2", 4, false, date2, users[6]))

var liked = Array<User>()
liked.append(users[3])
liked.append(users[5])
var post = Post(users[4], "Przykladowy opis", medias, comments, date1,liked)
// 2 post
var medias2 = Array<Media>()
var tagged3 = Array<User>()
tagged3.append(users[3])
tagged3.append(users[7])
medias2.append(Photo("imgsrc4.png", tagged3))
medias2.append(Video("vidsrc33.mp4", 60))

var comments2 = Array<Comment>()
date2 = dateFormatter.date(from: "27-04-2022") ?? Date.now
comments2.append(Comment("komentarz1", 13, false, date2, users[3]))
date2 = dateFormatter.date(from: "24-04-2022") ?? Date.now
comments2.append(Comment("komentarz2", 4, false, date2, users[2]))
date2 = dateFormatter.date(from: "20-04-2022") ?? Date.now

var liked2 = Array<User>()
liked2.append(users[2])

var post2 = Post(users[8], "opis przykladowy", medias2, comments2, date2, liked2)

// 3 post
var medias3 = Array<Media>()

medias3.append(Photo("imgsrc7.png", Array<User>()))

var comments3 = Array<Comment>()
date2 = dateFormatter.date(from: "27-04-2018") ?? Date.now
comments3.append(Comment("komentarz1", 1300, false, date2, users[3]))
date2 = dateFormatter.date(from: "24-04-2018") ?? Date.now
comments3.append(Comment("komentarz2", 4320, false, date2, users[2]))
date2 = dateFormatter.date(from: "20-04-2018") ?? Date.now

var liked3 = Array<User>()
liked3.append(users[0])
liked3.append(users[1])
liked3.append(users[2])
liked3.append(users[3])
liked3.append(users[4])
liked3.append(users[5])

var post3 = Post(User("CristianoRonaldo7", "cr7img.jpg"), "opis przykladowy3", medias3, comments3, date2, liked3)

//Pokazanie postów
var posts = Array<Post>()
posts.append(post)
posts.append(post2)
posts.append(post3)
showPosts(posts)

print(Date.now)

