import Cocoa
//4. Extended data model
struct Location {
    var id = 0
    var type: String
    var name: String
    var rating = 1
    
    init(_ id: Int, _ type: String, _ name:String, _ rating: Int){
        self.id = id
        self.type = type
        self.name = name
        self.rating = rating
    }
    
}


//1.Data model
class City {
    var id=0
    var name:String
    var description:String
    var latitude = 0.0
    var longitude = 0.0
    var keywords = Array<String>()
    var locations = Array<Location>() // 4. Extended data model
    init(_ id: Int, _ name: String, _ description:String, _ latitude: Double, _ longitude: Double, _ keywords: Array<String>, _ locations: Array<Location>)
    {
        self.id = id
        self.name = name
        self.description = description
        self.latitude = latitude
        self.longitude = longitude
        self.keywords = keywords
        self.locations = locations
    }
    
}

//2. Search
func searchByName(_ cities: [City],_ name: String) -> [City]{
    var found_cities = [City]()
    for city in cities {
        if (city.name == name)
        {
            found_cities.append(city)
        }
    }
    return found_cities
}

func searchByKeyword(_ cities: [City],_ keyword: String) -> [City]{
    var found_cities = [City]()
    for city in cities {
        for tag in city.keywords{
            if tag == keyword {
                found_cities.append(city)
            }
        }
    }
    return found_cities
}

//3. Distance

func distanceHelper(_ latitude1: Double, _ latitude2: Double, _ longitude1: Double, _ longitude2: Double) -> Double{
    //return sqrt(pow(latitude1 - latitude2, 2)+pow(longitude1 - longitude2, 2))
    let fi1 = latitude1 * Double.pi/180
    let fi2 = latitude2 * Double.pi/180
    let dfi = (latitude2 - latitude1) * Double.pi/180
    let dl = (longitude2 - longitude1) * Double.pi/180
    
    let a = sin(dfi/2) * sin(dfi/2) + cos(fi1) * cos(fi2) * sin(dl/2) * sin(dl/2)
    let c = 2 * atan2(sqrt(a),sqrt(1-a))
    return c * 6371
}

func distance(_ city1: City, _ city2: City) -> Double{
    //let distance = sqrt(pow(city1.latitude - city2.latitude, 2)+pow(city1.longitude - city2.latitude, 2))
    //return distance * 111
    return distanceHelper(city1.latitude, city2.latitude, city1.longitude, city2.longitude)
}

func closestAndFarthestCity(_ latitude: Double, _ longitude: Double, _ cities: [City]) -> (closest: City, farthest: City){
    var closest_city: City = cities[0]
    var farthest_city: City = cities[0]
    var closest_distance = distanceHelper(latitude, cities[0].latitude, longitude, cities[0].longitude)
    var farthest_distance = closest_distance
    
    for city in cities {
        let cities_distance = distanceHelper(latitude, city.latitude, longitude, city.longitude)
        if cities_distance < closest_distance {
            closest_distance = cities_distance
            closest_city = city
        }
        if cities_distance > farthest_distance {
            farthest_distance = cities_distance
            farthest_city = city
        }
    }
    
    return (closest: closest_city, farthest: farthest_city)
}

func twoFarthestCities(_ cities: [City]){
    var f_city1 = cities[0]
    var f_city2 = cities[1]
    var farthest_distance = distanceHelper(f_city1.latitude, f_city2.latitude, f_city1.longitude, f_city2.longitude)
    
    for city1 in cities {
        for city2 in cities {
            let dist = distanceHelper(city1.latitude, city2.latitude, city1.longitude, city2.longitude)
            if dist > farthest_distance {
                f_city1 = city1
                f_city2 = city2
                farthest_distance = dist
            }
        }
    }
    print("Farthest cities: \(f_city1.name) and  \(f_city2.name)")
}


//5. Advance search

func display5starRestaurantCities(_ Cities:[City]){
    var five_star_restaurant_cities = [City]()
    for city in Cities {
        for location in city.locations {
            if location.type == "restaurant" && location.rating == 5 {
                five_star_restaurant_cities.append(city)
            }
        }
    }
    print("Cities that have 5 star restaurants:")
    for five_star_restaurant_city in five_star_restaurant_cities {
        print(five_star_restaurant_city.name)
    }
}

func relatedLocations(_ city:City) -> [Location] {
    return city.locations.sorted { $0.rating > $1.rating}
}

func display5starCities(_ Cities:[City]){
    print("Cities with 5 star locations:")
    for city in Cities {
        var five_star_locations = [Location]()
        for location in city.locations {
            if location.rating == 5 {
                five_star_locations.append(location)
            }
        }
        if five_star_locations.count > 0{
            print("\(city.name) 5 star locations: \(five_star_locations.count)")
            var i = 0
            for five_star_location in five_star_locations {
                i+=1
                if i < five_star_locations.count {
                    print(five_star_location.name,terminator: ", ")
                    
                }
                else {
                    print(five_star_location.name,terminator: "")
                }
            }
            print("")
            print("")
        }
    }
}


var locations = [Location]()
locations.append(Location(0,"restaurant","rest1",5))
locations.append(Location(1,"restaurant","KFC",3))
locations.append(Location(2,"museum","museum1",5))

var locations2 = [Location]()
locations2.append(Location(3,"museum","museum3",4))
locations2.append(Location(4,"monument","monument3",4))
locations2.append(Location(5,"restaurant","restaurant5",4))


var cities = [City]()

cities.append(City(0, "Paris", "French Capital", 48.855379999322075, 2.3563138925415053, ["art", "sport", "architecture"], locations))

locations = [Location]()
locations.append(Location(6,"restaurant","rest2",5))
locations.append(Location(7,"pub","pub1",5))
locations.append(Location(8,"museum","museum2",4))
locations.append(Location(9,"stadium","Camp nou",5))
cities.append(City(1, "Barcelona", "City in Catalonia", 41.39954787582139, 2.148861935411274, ["seaside", "sport", "music"], locations))

locations = [Location]()
locations.append(Location(10,"restaurant","rest3",4))
locations.append(Location(11,"pub","pub2",4))
locations.append(Location(12,"monument","monument1",4))
cities.append(City(2, "Madrit", "Capital of Spain", 40.40911992393966, -3.7083832901803326, ["food", "sport"], locations))

locations = [Location]()
locations.append(Location(13,"restaurant","rest4",4))
locations.append(Location(14,"pub","pub3",5))
locations.append(Location(15,"monument","monument2",5))
cities.append(City(3, "Sevilla", "City in Spain", 37.41045500577149, -5.984753609831334, ["party", "sport", "architecture"], locations))

locations2 = [Location]()
locations2.append(Location(16,"restaurant","restaurant6",3))
locations2.append(Location(17,"monument","monument3",3))
locations2.append(Location(18,"restaurant","restaurant5",4))
cities.append(City(4, "Mallorca", "City in Spain", 39.712536164237456, 3.024230979886382, ["seaside", "party", "music"], locations2))

locations2 = [Location]()
locations2.append(Location(19,"restaurant","restaurant7",3))
locations2.append(Location(20,"restaurant","restaurant8",5))
cities.append(City(5, "Montreal", "City in Canada", 45.55555248998006, -73.73236932527537, ["seaside", "architecture"], locations2))

locations2 = [Location]()
locations2.append(Location(21,"pub","pub6",5))
locations2.append(Location(22,"sports hall","Lakers' Arena",5))
locations2.append(Location(23,"restaurant","restaurant7",5))
cities.append(City(6, "Los Angeles", "City in USA", 34.04406097894775, -118.27443642013944, ["party", "sport", "music"], locations2))

locations2 = [Location]()
locations2.append(Location(24,"pub","pub7",4))
locations2.append(Location(25,"casino","casino1",5))
locations2.append(Location(26,"restaurant","restaurant9",4))
cities.append(City(7, "Las Vegas", "City in USA", 36.28736557325284, -115.40204160502682, ["party", "gambling", "music"], locations2))

locations2 = [Location]()
locations2.append(Location(27,"pub","pub8",4))
locations2.append(Location(28,"casino","casino2",4))
locations2.append(Location(29,"restaurant","restaurant10",3))
cities.append(City(8, "New York", "City in USA", 40.73462149180422, -74.07721448184736, [ "party", "shopping"], locations2))

locations2 = [Location]()
locations2.append(Location(30,"museum","museum12",4))
locations2.append(Location(31,"monument","monument12",3))
locations2.append(Location(32,"restaurant","restaurant9",4))
cities.append(City(9, "Toronto", "City in Canada", 43.67322944309295, -79.45547673369627, ["sport", "museums"], locations2))

locations2 = [Location]()
locations2.append(Location(33,"pub","pub7",4))
locations2.append(Location(34,"stadium","football stadium1",5))
locations2.append(Location(35,"monument","monument in rio",5))
cities.append(City(10, "Rio de Janeiro", "City in Brazil", -22.78606740295524, -43.436406230572665, ["seaside", "sport", "music"], locations2))

locations2 = [Location]()
locations2.append(Location(36,"pub","pub8",4))
locations2.append(Location(37,"stadium","football stadium2",4))
locations2.append(Location(38,"restaurant","restaurant14",3))
cities.append(City(11, "Buenos Aires", "City in Argentina", -34.48610460148215, -58.40032848049664, ["nature", "sport", "museums"], locations2))

locations2 = [Location]()
locations2.append(Location(39,"pub","pub8",4))
locations2.append(Location(40,"museum","museum in krakow",4))
locations2.append(Location(41,"restaurant","restaurant14",3))
cities.append(City(12, "Krakow", "City in Poland", 50.039625819040836, 19.978774242591818, [ "party", "museums"], locations2))

locations2 = [Location]()
locations2.append(Location(42,"museum","museum in berlin2",4))
locations2.append(Location(43,"museum","museum in berlin1 ",4))
locations2.append(Location(44,"restaurant","restaurant14",3))
cities.append(City(13, "Berlin", "City in Germany", 52.53158260809545, 13.457667527664983, ["shopping", "music", "museums"], locations2))

locations2 = [Location]()
locations2.append(Location(45,"pub","pub8",4))
locations2.append(Location(46,"museum","museum19 ",4))
locations2.append(Location(47,"restaurant","restaurant15",5))
cities.append(City(14, "Napoli", "City in Italy", 40.85488437502743, 14.266007644808175, ["architecture", "sport", "museums"], locations2))
locations2 = [Location]()
locations2.append(Location(48,"pub","pub8",4))
locations2.append(Location(49,"stadium","San Siro stadium",4))
locations2.append(Location(50,"restaurant","restaurant15",4))
cities.append(City(15, "Milan", "City in Italy", 45.47282503224054, 9.17429728557308, ["fashion", "sport", "museums"], locations2))

locations2 = [Location]()
locations2.append(Location(51,"monument","monument6",3))
locations2.append(Location(52,"museum","museum21 ",3))
locations2.append(Location(53,"restaurant","restaurant55",4))
cities.append(City(16, "Porto", "City in Portugal", 41.19492128339137, -8.532775997641851, ["seaside", "sport", "museums"], locations2))

locations2 = [Location]()
locations2.append(Location(54,"pub","pub28",5))
locations2.append(Location(55,"museum","museum20 ",4))
locations2.append(Location(56,"restaurant","restaurant17",2))
cities.append(City(17, "Manchester", "City in England", 53.48203263931345, -2.2334206755343797, ["music", "sport", "museums"], locations2))

locations2 = [Location]()
locations2.append(Location(57,"monument","monument123",4))
locations2.append(Location(58,"museum","museum29 ",4))
locations2.append(Location(59,"restaurant","restaurant18",4))
cities.append(City(18, "Ankara", "City in Turkey", 39.95796509936117, 32.82108259477947, ["food", "nature"], locations2))

locations2 = [Location]()
locations2.append(Location(60,"pub","pub8",4))
locations2.append(Location(61,"museum","museum19 ",4))
locations2.append(Location(62,"restaurant","restaurant15",3))
cities.append(City(19, "Bilbao", "City in Spain", 43.264755708754805, -2.934251545795992, ["food", "sport"], locations2))

//2. Search
print("2. Search:")
print("")

// searching by name
var searchedcities = searchByName(cities, "Barcelona")
print("Cities with name Barcelona:")
for city in searchedcities {
    print("\(city.name) - \(city.description)")
}

//search cities by keyword
print("")
var keyword:String = "music"
var searchedcities2 = searchByKeyword(cities, keyword)
print("Cities that has keyword: \(keyword)")
for city in searchedcities2 {
    print("\(city.name) - \(city.description)")
}

//3. Distance
print("")
print("3. Distance:")
print("")
var dis = distance(cities[0], cities[1])
print("Distance between \(cities[0].name) and \(cities[1].name) equals \(dis)km")

//get closest and farthest city
print("")
let latitude = 16.3
let longitude = 12.6
var twocities = closestAndFarthestCity(latitude, longitude, cities)
print("Closest city to coordinates \(latitude)\", \(longitude)\" is \(twocities.closest.name)")
print("Farthest city to coordinates \(latitude)\", \(longitude)\" is \(twocities.farthest.name)")

//display two farthest cities
print("")
twoFarthestCities(cities)

//5. Advance search
//displaying cities that have 5 star restaurant
print("")
print("5. Advanced search:")
print("")
display5starRestaurantCities(cities)
//returning list of related locations
print("")
var rellocations = relatedLocations(cities[1])
print("Locations related to \(cities[1].name):")
for loc in rellocations {
print("\(loc.name) \(loc.rating)")
}
//display all cities with 5 star locations
print("")
display5starCities(cities)
